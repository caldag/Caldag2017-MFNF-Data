---Microswimmer Research at Sabanci University---
    --- Explanation for Processed Data ---

This attachment contains all of the processed data discussed in:

Caldag, H. O., Acemoglu, A. & Yesilyurt, S. (2017). Swimming characteristics of artificial helical swimmers in circular channels. Manuscript submitted for publication.

The data files are classified under separate folders corresponding to the experiment configuration.

Letter D -> Channel diameter (D3 stands for 3 mm channel, D16 stands for 1.6 mm channel)
Letter L -> Swimmer tail length (L15 stands for 1.5 mm tail length, L4 stands for 4 mm tail length)
Letter Q -> Reference flowrate in mL/min for a channel with diameter of 1 mm.

Data for each rotation rate are in separate .dat files with file names corresponding to rotation rates (in Hz).

Files with "-" sign in front implies puller mode rotation.

.dat files store the data in columns in following order:

Column No.  |  Data
----------------------
1	    	Time
2		x-Coordinate
3		y-Coordinate
4		z-Coordinate
5		r_sw
6		beta
7		theta_ax
8		u_sw
9		v_th

Time -> Time instant (in s)
x-, y- and z- Position: Cartesian position of the swimmer, (in mm)
r_sw -> Radial position of the swimmer (in mm)
beta -> Nondimensionalized radial position of the swimmer. beta=0 means the swimmer is at the center, beta=1 means the swimmer touches the channel wall.
theta_ax -> Angle between the direction of the swimmer and centerline of the channel (in degrees)
u_sw -> Swimming velocity in x- direction (mm/s)
v_th -> Lateral velocity, in theta- direction (mm/s)


